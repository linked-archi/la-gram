/**
 * Palette Generator implementation.
 *
 * Builds the tool palette out of the three layers a Linked.Archi metamodel
 * publishes, each of which already has a module of its own:
 *
 * - **taxonomy** (`taxonomy.ts`) — which classes are instantiable, and how they
 *   group along each classification axis ("Domain", "Aspect"). The axis is
 *   what a "Group by" selector switches between.
 * - **notation** (`notation.ts`) — the `arch-vis:` visual style per concept,
 *   scoped to a notation set.
 * - **ontology** — `rdfs:subClassOf+ arch:QualifiedRelationship` for the
 *   relationship types, with `arch:domainIncludes` / `arch:rangeIncludes`
 *   gathered from the class *and* from whatever `arch:unqualifiedForm` names,
 *   exactly as `RelationshipManager` does it.
 *
 * ## Notation lookup
 *
 * Each class is styled by `notation-resolver.ts`, in five steps (Req 2.16).
 *
 * For a class C, the active set A is the set that the active presentation
 * context names with `arch:usesNotationSet`, or else the primary metamodel's
 * `arch:notationSet`. The fallback layers F are the default sets
 * (`arch:notationSet`) of all loaded metamodels except A itself, in load order.
 * F includes the default set of A's own metamodel when a presentation context
 * picked an alternative set.
 *
 * 1. A descriptor in A for C.
 * 2. A descriptor for C in F, the first match in load order.
 * 3. C's own `arch:prefVisNotation`.
 * 4. A descriptor for the nearest superclass of C that has one in A or F. The
 *    walk goes breadth-first over `rdfs:subClassOf`: by distance first, and
 *    superclasses at the same distance in IRI order. It stops at `arch:Element`
 *    and `arch:QualifiedRelationship`. For each superclass, A is checked first,
 *    then F in load order.
 * 5. Built-in defaults. Elements: a rectangle with a white fill and a black
 *    line. Relationships: a solid black line.
 *
 * Anything published for the class itself beats anything inherited; among
 * inherited descriptors the nearest ancestor wins; the active set only breaks
 * ties.
 *
 * Here a set chosen explicitly (`PaletteOptions.notationSetIri`) comes before
 * the context's, and the primary metamodel is the first of
 * `PaletteOptions.defaultNotationSetIris` whose set has descriptors.
 *
 * The palette entries and the `notationIndex` the canvas reads come from the
 * same resolver, so palette and canvas cannot disagree.
 *
 * ## Why this is not SPARQL any more
 *
 * The previous implementation queried `?type rdfs:subClassOf+ arch:Element`,
 * grouped by a single `skos:broader` hop, filtered on `arch:isAbstract`, and
 * looked for `?rel a arch:Relationship`. Against the published ArchiMate 4.0
 * data every one of those is wrong: grouping is multi-axis through
 * `skos:narrower` onto the OWL classes, the abstractness flag is
 * `arch:isAbstractClass`, and `arch:Relationship` does not occur at all —
 * relationship types are `owl:Class`es under `arch:QualifiedRelationship`.
 *
 * `taxonomy.ts` and `notation.ts` encode those rules and operate on an n3
 * `Store`, so this module reads the quads out of the application's `RdfStore`
 * and hands them a snapshot rather than duplicating the logic in SPARQL.
 *
 * ## Icons
 *
 * Icon URIs are published absolute (`https://meta.linked.archi/archimate4/…`).
 * They are passed through {@link resolveIconUri} so the bundled copies load with
 * no network, and the published URI is kept alongside in a {@link ResolvedUri}
 * so a caller with network access can still choose it.
 */

import { declaredOutside, documentsWithoutTypes, metamodelCompleteness } from './metamodel-completeness.js';
import { DataFactory, Store } from 'n3';
import type { Quad as N3Quad } from 'n3';
import type { Quad } from '@rdfjs/types';
import type { RdfStore } from '../rdf-engine/interfaces.js';
import { NAMESPACES } from '../rdf-engine/namespaces.js';
import { resolveIconUri } from './bundled-assets.js';
import {
  buildClasses,
  buildClassificationAxes,
  paletteGroupingOf,
  type SemanticClass,
  type TaxonomyAxis,
} from './taxonomy.js';
import {
  buildDecorationSymbols,
  buildVisualNotations,
  effectiveRenderingMode,
  labelExpressionIn,
  labelExpressionsOf,
  presentationContextLabel,
  resolveNotationSetForContext,
  type Decoration,
  type NotationSet,
  type RelationshipVisualStyle,
  type VisualNotation,
  type VisualStyle,
} from './notation.js';
import { NOTATION_ROOTS, buildSuperClassMap, closureOf, compareIris, superClassesNearestFirst } from './class-hierarchy.js';
import {
  coreNotationSetIris,
  NotationResolver,
  orderedFallbackSets,
  storeDefaultNotationSetIris,
  type NotationIndexEntry,
  type ResolvedNotation,
} from './notation-resolver.js';
import type {
  PaletteGenerator,
  PaletteDefinition,
  PaletteOptions,
  PaletteAxis,
  ElementTypeInfo,
  ElementGroup,
  RelationshipTypeInfo,
  ResolvedUri,
} from './interfaces.js';

const { namedNode } = DataFactory;

const RDF_TYPE = `${NAMESPACES.rdf}type`;
const RDFS_LABEL = `${NAMESPACES.rdfs}label`;
const RDFS_COMMENT = `${NAMESPACES.rdfs}comment`;
const RDFS_SUBCLASS_OF = `${NAMESPACES.rdfs}subClassOf`;
const SKOS_PREF_LABEL = `${NAMESPACES.skos}prefLabel`;
const SKOS_DEFINITION = `${NAMESPACES.skos}definition`;

const ARCH_QUALIFIED_RELATIONSHIP = `${NAMESPACES.arch}QualifiedRelationship`;
const ARCH_RELATIONSHIP_LEGACY = `${NAMESPACES.arch}Relationship`;
const ARCH_UNQUALIFIED_FORM = `${NAMESPACES.arch}unqualifiedForm`;
const RDFS_SEE_ALSO = `${NAMESPACES.rdfs}seeAlso`;
const OWL_SYMMETRIC_PROPERTY = `${NAMESPACES.owl}SymmetricProperty`;
const ARCH_DOMAIN_INCLUDES = `${NAMESPACES.arch}domainIncludes`;
const ARCH_RANGE_INCLUDES = `${NAMESPACES.arch}rangeIncludes`;
const ARCH_IS_ABSTRACT_CLASS = `${NAMESPACES.arch}isAbstractClass`;

/**
 * How real viewpoints express membership.
 *
 * Verified against `archimate4-viewpoints.ttl`: every one of the 18 viewpoints
 * uses `arch:includesConcept`, and `arch:permitsElement` /
 * `arch:permitsRelationship` — which the previous implementation assumed —
 * appear nowhere. The core ontology types `arch:includesConcept` with
 * `rdfs:range arch:ModelConcept`, so one predicate covers both elements and
 * relationship types.
 */
const ARCH_INCLUDES_CONCEPT = `${NAMESPACES.arch}includesConcept`;
/** Legacy membership predicates, still honoured for older/hand-written data. */
const ARCH_PERMITS_ELEMENT = `${NAMESPACES.arch}permitsElement`;
const ARCH_PERMITS_RELATIONSHIP = `${NAMESPACES.arch}permitsRelationship`;

/** Group label used when an element has no group under the active axis. */
const UNCATEGORIZED = 'Other';

/**
 * PaletteGenerator over the metamodel quads held in an {@link RdfStore}.
 *
 * Each `generatePalette` call takes a fresh snapshot of the store, so a palette
 * generated after loading more of the metamodel reflects the addition.
 */
export class SparqlPaletteGenerator implements PaletteGenerator {
  constructor(private store: RdfStore) {}

  /**
   * Build a palette from everything currently in the store.
   *
   * @param metamodelGraph Retained for call-site compatibility and used only to
   *   scope the snapshot when that graph exists on its own. A metamodel spans
   *   several named graphs (ontology, taxonomy, notation …), and the taxonomy
   *   and notation layers must see all of them, so by default the snapshot is
   *   the whole store.
   * @param options Which axis to group by and which notation set to style from.
   */
  generatePalette(metamodelGraph?: string, options?: PaletteOptions): PaletteDefinition {
    const graph = this.snapshot();

    const classificationAxes = buildClassificationAxes(graph, options?.metamodelIris);
    // Not the classes of a document that gives no loaded metamodel its types: another version's ontology, loaded
    // because the shapes of both import it (LeanIX v3 beside v4, TOGAF 9.2 beside 10).
    const withoutTypes = options?.metamodels ? documentsWithoutTypes(graph, options.metamodels) : new Set<string>();
    const semanticClasses = buildClasses(graph, classificationAxes).filter((cls) => declaredOutside(graph, cls.iri, withoutTypes));
    // Only an axis that groups some element type is one to group the palette by. A taxonomy may also
    // classify relationship types — ArchiMate's relationship categories — which are not palette elements.
    // A standalone group (ArchiMate's Junction, under no axis) is no way of grouping either: its members take
    // a section of its name when no grouping axis classifies them.
    const taxonomyAxes = classificationAxes.filter(
      (axis) => !axis.standalone && semanticClasses.some((cls) => cls.groupsByAxis[axis.iri] !== undefined),
    );
    const standaloneAxes = classificationAxes.filter((axis) => axis.standalone).map((axis) => axis.iri);

    const activeAxis = this.pickAxis(taxonomyAxes, options?.axisIri);
    // The axes the palette is grouped by, the active one first: under an axis the metamodel's palette
    // grouping names (arch:paletteGrouping), the others it names follow, in its order — they place a class
    // the active axis does not classify, and order the classes within a section. Under any other axis, it alone.
    const grouping = paletteGroupingOf(graph, options?.metamodelIris).filter((iri) =>
      taxonomyAxes.some((axis) => axis.iri === iri),
    );
    const groupingAxes = !activeAxis
      ? []
      : grouping.includes(activeAxis.iri)
        ? [activeAxis.iri, ...grouping.filter((iri) => iri !== activeAxis.iri)]
        : [activeAxis.iri];
    const notationSet = this.resolveNotationSet(graph, options);

    // One hierarchy map and one resolver per palette: relationship discovery,
    // the palette entries and the canvas index all read the same answers.
    const superClassMap = buildSuperClassMap(graph);
    const fallbackSets = orderedFallbackSets(graph, notationSet?.iri, [
      ...(options?.defaultNotationSetIris ?? storeDefaultNotationSetIris(graph)),
      // The core's own relationship types, after every language's; nesting may draw Has Part and Refines (VC-DD-5).
      ...coreNotationSetIris(graph),
    ]);
    const resolver = new NotationResolver(graph, notationSet, fallbackSets, superClassMap);

    // The dimensions the grouping does not name place what it leaves out, after its own sections: the types of
    // a metamodel loaded beside the first — the decision extension's records and forces beside ArchiMate's
    // domains — keep their own groups, not "Other".
    const otherAxes = groupingAxes.length > 0 ? taxonomyAxes.map((axis) => axis.iri).filter((iri) => !groupingAxes.includes(iri)) : [];
    const elements = semanticClasses.map((cls) => this.toElementTypeInfo(cls, groupingAxes, standaloneAxes, resolver, otherAxes));
    const elementGroups = this.groupElements(elements, activeAxis, groupingAxes, semanticClasses, otherAxes);
    const relationshipTypes = categoriseRelationships(
      this.discoverRelationships(graph, resolver, superClassMap).filter((rel) => declaredOutside(graph, rel.iri, withoutTypes)),
      classificationAxes,
      superClassMap,
      graph,
    );
    const notationIndex = buildNotationIndex(graph, resolver, superClassMap, [
      ...(notationSet ? [notationSet] : []),
      ...fallbackSets,
    ]);

    const axes: PaletteAxis[] = taxonomyAxes.map((axis) => ({
      iri: axis.iri,
      label: axis.label,
      groups: groupsInOrder(axis),
    }));

    // `metamodelGraph` is deliberately unused for scoping — see the doc above.
    void metamodelGraph;

    const groupedByName = taxonomyAxes.length === 0;
    const completeness = options?.metamodels
      ? metamodelCompleteness(graph, options.metamodels, semanticClasses, relationshipTypes, groupedByName)
      : [];

    return {
      elementGroups,
      relationshipTypes,
      ...(completeness.length > 0 ? { completeness } : {}),
      axes,
      activeAxisIri: activeAxis?.iri,
      // buildClasses walks the OWL classes when there is no axis to group by.
      grouping: taxonomyAxes.length > 0 ? 'taxonomy' : 'owl',
      notationSetIri: notationSet?.iri,
      notationSetLabel: notationSet?.label,
      ...this.presentationContextOf(graph, options?.presentationContextIri),
      notationIndex,
      decorationSymbols: resolvedDecorationSymbols(graph),
    };
  }

  /**
   * Restrict a palette to the concepts a viewpoint includes.
   *
   * ArchiMate viewpoints list element types only — `arch:includesConcept` never
   * names a relationship type in the published data. Filtering relationships
   * against an element-only list would empty the relationship section, so
   * relationships are filtered only when the viewpoint actually names at least
   * one of them. A viewpoint that names nothing at all leaves the palette
   * untouched: `arch:includesConcept` is documented as a palette hint, not a
   * restriction.
   */
  filterByViewpoint(palette: PaletteDefinition, viewpointIri: string): PaletteDefinition {
    const included = this.readViewpointConcepts(viewpointIri);
    if (included.size === 0) return palette;

    const elementGroups: ElementGroup[] = palette.elementGroups
      .map((group) => ({ ...group, elements: group.elements.filter((e) => included.has(e.iri)) }))
      .filter((group) => group.elements.length > 0);

    const namedRelationships = palette.relationshipTypes.filter((r) => included.has(r.iri));
    const relationshipTypes =
      namedRelationships.length > 0 ? namedRelationships : palette.relationshipTypes;

    return { ...palette, elementGroups, relationshipTypes };
  }

  // ── Snapshot ─────────────────────────────────────────────────────────

  /**
   * Copy the store's quads into an n3 `Store`.
   *
   * `taxonomy.ts` and `notation.ts` take an n3 `Store` — they are synchronous,
   * unit-testable against hand-written Turtle, and independent of the
   * application's RDF abstraction. Quads keep their graph term; n3 treats a
   * `null` graph argument as a wildcard, which is what both modules pass, so
   * per-document graphs stay visible without special handling.
   */
  private snapshot(): Store {
    // Over the application's store: the metamodel graphs read into a store, and
    // the model's copy as it is — not copied into it too (Task 22). Not kept
    // between palettes: the metamodels' quads held in JavaScript cost 100 MB.
    const observed = this.store as RdfStore & { modelGraph?(): Store; namedGraphQuads?(): Quad[] };
    if (observed.modelGraph && observed.namedGraphQuads) {
      const named = new Store();
      named.addQuads(observed.namedGraphQuads() as unknown as N3Quad[]);
      return unionOf(named, observed.modelGraph());
    }
    const graph = new Store();
    for (const q of this.store.getQuads()) {
      // The application's Quad is @rdfjs/types-shaped and n3's addQuad wants its
      // own term unions; the terms are the same objects (both come from n3's
      // DataFactory), so the assertion is a typing bridge, not a conversion.
      graph.addQuad(
        q.subject as unknown as N3Quad['subject'],
        q.predicate as unknown as N3Quad['predicate'],
        q.object as unknown as N3Quad['object'],
        q.graph as unknown as N3Quad['graph'],
      );
    }
    return graph;
  }

  // ── Elements ─────────────────────────────────────────────────────────

  /** The axis to group by: the requested one, else the taxonomy's preferred one. */
  private pickAxis(axes: TaxonomyAxis[], axisIri?: string): TaxonomyAxis | undefined {
    if (axisIri) {
      const requested = axes.find((axis) => axis.iri === axisIri);
      if (requested) return requested;
    }
    return axes[0];
  }

  /**
   * The active notation set: an explicit IRI, else the set a presentation
   * context asks for, else the first of the loaded metamodels' default sets that
   * has descriptors, else the graph's default (resolved inside
   * `buildVisualNotations`).
   *
   * Taking the primary metamodel's set when the caller gives the load order is
   * what makes the default deterministic with several metamodels loaded: the
   * graph alone yields whichever `arch:notationSet` the store iterates first.
   */
  /** The presentation context chosen — its name, and what it says every label says (its own label expression). */
  private presentationContextOf(
    graph: Store,
    contextIri: string | undefined,
  ): Pick<PaletteDefinition, 'presentationContextIri' | 'presentationContextLabel' | 'presentationContextLabelExpression'> {
    if (!contextIri) return {};
    const expression = labelExpressionIn(labelExpressionsOf(graph, DataFactory.namedNode(contextIri)), contextIri);
    return {
      presentationContextIri: contextIri,
      presentationContextLabel: presentationContextLabel(graph, contextIri),
      ...(expression !== undefined ? { presentationContextLabelExpression: expression } : {}),
    };
  }

  private resolveNotationSet(graph: Store, options?: PaletteOptions): NotationSet | null {
    if (options?.notationSetIri) return buildVisualNotations(graph, options.notationSetIri);
    if (options?.presentationContextIri) {
      const fromContext = resolveNotationSetForContext(graph, options.presentationContextIri);
      if (fromContext) return buildVisualNotations(graph, fromContext);
    }
    for (const iri of options?.defaultNotationSetIris ?? []) {
      const set = buildVisualNotations(graph, iri);
      if (set) return set;
    }
    return buildVisualNotations(graph);
  }

  private toElementTypeInfo(
    cls: SemanticClass,
    groupingAxes: readonly string[],
    standaloneAxes: readonly string[],
    resolver: NotationResolver,
    otherAxes: readonly string[] = [],
  ): ElementTypeInfo {
    // The five-step lookup (module doc). Its `prefVisNotation` already applies
    // the guide's fallback to the class's own arch:prefVisNotation.
    const resolved = resolver.resolve(cls.iri);
    const notation = resolved.notation;
    const prefVisNotation = resolveUri(resolved.prefVisNotation);
    const iconSymbol = resolveUri(notation?.style?.iconSymbol);
    const style = styleWithResolvedIcon(notation);

    // A class's section is its group under the active axis; one that axis does not classify takes its
    // group under the next axis the palette grouping names — never another axis's on a guess — then the
    // standalone group that lists it (Junction), then its group under a dimension the grouping does not name
    // (another loaded metamodel's), else "Other". With no axis at all the taxonomy's own default group (its
    // OWL-only fallback) is used.
    const group =
      groupingAxes.length > 0
        ? (sectionOf(cls, groupingAxes)?.group ??
          standaloneAxes.map((iri) => cls.groupsByAxis[iri]).find(Boolean) ??
          sectionOf(cls, otherAxes)?.group)
        : cls.group;

    return {
      iri: cls.iri,
      label: cls.label,
      definition: cls.definition,
      iconUrl: prefVisNotation?.url ?? iconSymbol?.url,
      prefVisNotation,
      iconSymbol,
      style,
      renderingMode: style ? effectiveRenderingMode(style) : undefined,
      group: group || UNCATEGORIZED,
      groupsByAxis: cls.groupsByAxis,
      isAbstract: cls.isAbstract,
    };
  }

  /**
   * Bucket elements by their section. Sections come in the order of the axis that gave them — the active
   * axis's first, then the next grouping axis's — each in its axis's order (its thesaurus array's), then
   * by label; "Other" last. Within a section, elements follow their groups' order under the other grouping
   * axes, then their labels.
   */
  private groupElements(
    elements: ElementTypeInfo[],
    activeAxis: TaxonomyAxis | undefined,
    groupingAxes: readonly string[],
    classes: readonly SemanticClass[],
    otherAxes: readonly string[] = [],
  ): ElementGroup[] {
    const classOf = new Map(classes.map((cls) => [cls.iri, cls]));
    const buckets = new Map<string, ElementTypeInfo[]>();
    /** A section's place: which grouping axis gave it, and its rank there (the lowest of its classes'). */
    const place = new Map<string, [number, number]>();
    const LAST = Number.MAX_SAFE_INTEGER;
    for (const element of elements) {
      const category = element.group || UNCATEGORIZED;
      const bucket = buckets.get(category);
      if (bucket) bucket.push(element);
      else buckets.set(category, [element]);
      const cls = classOf.get(element.iri);
      const section = cls && groupingAxes.length > 0 ? sectionOf(cls, groupingAxes) : undefined;
      // A section from a dimension the grouping does not name comes after the grouping's, in that dimension's order.
      const other = cls && !section && element.group !== UNCATEGORIZED ? sectionOf(cls, otherAxes) : undefined;
      const here: [number, number] = section
        ? [section.axis, section.rank ?? LAST]
        : other && other.group === element.group
          ? [groupingAxes.length + other.axis, other.rank ?? LAST]
          : [LAST, LAST];
      const before = place.get(category);
      if (!before || here[0] < before[0] || (here[0] === before[0] && here[1] < before[1])) place.set(category, here);
    }

    // Within a section: first the order its group gives its own members, where it gives one (an array under
    // the group — ArchiMate 4.0's Common Domain: process, function, service, event…); then the groups' order
    // under the other grouping axes (the aspects); then, after this, the label.
    const withinKey = (element: ElementTypeInfo, sectionAxis: number): number[] => {
      const cls = classOf.get(element.iri);
      const own = groupingAxes[sectionAxis];
      return [
        own !== undefined ? (cls?.memberRanksByAxis?.[own] ?? LAST) : LAST,
        ...groupingAxes.filter((_, i) => i !== sectionAxis).map((axis) => cls?.ranksByAxis[axis] ?? LAST),
      ];
    };
    const compareKeys = (a: number[], b: number[]): number => {
      for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return (a[i] ?? LAST) - (b[i] ?? LAST);
      return 0;
    };

    return [...buckets.entries()]
      .map(([category, groupElements]) => {
        const sectionAxis = place.get(category)?.[0] ?? LAST;
        return {
          category,
          axisIri: activeAxis?.iri,
          elements: groupElements.sort(
            (a, b) => compareKeys(withinKey(a, sectionAxis), withinKey(b, sectionAxis)) || a.label.localeCompare(b.label),
          ),
        };
      })
      .sort((a, b) => {
        if ((a.category === UNCATEGORIZED) !== (b.category === UNCATEGORIZED)) return a.category === UNCATEGORIZED ? 1 : -1;
        const [axisA, rankA] = place.get(a.category) ?? [LAST, LAST];
        const [axisB, rankB] = place.get(b.category) ?? [LAST, LAST];
        return axisA - axisB || rankA - rankB || a.category.localeCompare(b.category);
      });
  }

  // ── Relationships ────────────────────────────────────────────────────

  /**
   * Relationship types: `owl:Class`es whose `rdfs:subClassOf+` closure reaches
   * `arch:QualifiedRelationship`.
   *
   * `+` rather than `*` because the intermediate steps are real (ArchiMate's
   * `Composition` subclasses `Aggregation`) and `arch:QualifiedRelationship`
   * itself is not a relationship type. A legacy `?rel a arch:Relationship`
   * typing is also accepted so hand-written metamodels keep working, even though
   * the published ArchiMate 4.0 data never uses it.
   */
  private discoverRelationships(
    graph: Store,
    resolver: NotationResolver,
    superClassMap: Map<string, string[]>,
  ): RelationshipTypeInfo[] {
    const candidates = new Set<string>();
    for (const [iri, supers] of superClassMap) {
      if (supers.length === 0) continue;
      if (closureOf(iri, superClassMap).includes(ARCH_QUALIFIED_RELATIONSHIP)) candidates.add(iri);
    }
    for (const subject of graph.getSubjects(
      namedNode(RDF_TYPE),
      namedNode(ARCH_RELATIONSHIP_LEGACY),
      null,
    )) {
      if (subject.termType === 'NamedNode') candidates.add(subject.value);
    }

    const relationships: RelationshipTypeInfo[] = [];

    for (const iri of candidates) {
      if (iri === ARCH_QUALIFIED_RELATIONSHIP) continue;
      if (isAbstractClass(graph, iri)) continue;

      const unqualifiedPredicateIri = objectValue(graph, iri, ARCH_UNQUALIFIED_FORM);

      // ArchiMate 4.0 hangs the constraints off the unqualified *property*
      // (am4:serves), C4 repeats them on both; gather from each and dedupe.
      const constraintSubjects = [iri, ...(unqualifiedPredicateIri ? [unqualifiedPredicateIri] : [])];
      const domainTypes = uniqueInOrder(
        constraintSubjects.flatMap((subject) => objectValues(graph, subject, ARCH_DOMAIN_INCLUDES)),
      );
      const rangeTypes = uniqueInOrder(
        constraintSubjects.flatMap((subject) => objectValues(graph, subject, ARCH_RANGE_INCLUDES)),
      );

      // Same lookup as the elements. A descriptor carries a line colour only
      // when it states one; with none the renderer draws black.
      const resolved = resolver.resolve(iri);
      const prefVisNotation = resolveUri(resolved.prefVisNotation);

      relationships.push({
        iri,
        label: labelFor(graph, iri),
        definition: definitionFor(graph, iri),
        iconUrl: prefVisNotation?.url,
        prefVisNotation,
        relationshipStyle: resolved.notation?.relationshipStyle ?? unstyledRelationship(graph, unqualifiedPredicateIri),
        domainTypes,
        rangeTypes,
        unqualifiedPredicateIri,
        ...(iri.startsWith(NAMESPACES.arch) ? { core: true } : {}),
      });
    }

    return relationships.sort((a, b) => a.label.localeCompare(b.label));
  }

  // ── Viewpoints ───────────────────────────────────────────────────────

  /**
   * The concept IRIs a viewpoint names, and their subclasses — a viewpoint
   * naming a class includes its subclasses, as `ViewpointManager` reads it.
   *
   * Read straight off the store rather than through SPARQL so the IRI never has
   * to be interpolated into a query string.
   */
  private readViewpointConcepts(viewpointIri: string): Set<string> {
    const concepts = new Set<string>();
    const subject = namedNode(viewpointIri);
    for (const predicate of [
      ARCH_INCLUDES_CONCEPT,
      ARCH_PERMITS_ELEMENT,
      ARCH_PERMITS_RELATIONSHIP,
    ]) {
      for (const q of this.store.getQuads(subject, namedNode(predicate), null, null)) {
        if (q.object.termType === 'NamedNode') concepts.add(q.object.value);
      }
    }
    // A Set visits what is added during iteration, so this walks the closure.
    for (const iri of concepts) {
      for (const q of this.store.getQuads(null, namedNode(RDFS_SUBCLASS_OF), namedNode(iri), null)) {
        if (q.subject.termType === 'NamedNode') concepts.add(q.subject.value);
      }
    }
    return concepts;
  }
}

// ── Module-level graph helpers ──────────────────────────────────────────

/**
 * The canvas's copy of the notation lookup (`PaletteDefinition.notationIndex`).
 *
 * Covers every class the graph declares, every class a consulted set describes
 * (a set may describe a class whose ontology is not loaded) and the two roots;
 * classes that resolve to nothing are left out, so the renderer's defaults
 * apply. Each class's `arch:unqualifiedForm` predicate is added as an alias,
 * because a model triple uses the predicate, never overwriting a class key.
 * A predicate a class shares with its subclasses aliases the class: a bare
 * `am4:accesses` triple is an `am4:Access`, not an `am4:ReadAccess`. Keys are
 * visited in IRI order so a predicate unrelated classes share always aliases
 * the same one.
 */
function buildNotationIndex(
  graph: Store,
  resolver: NotationResolver,
  superClassMap: ReadonlyMap<string, readonly string[]>,
  consultedSets: readonly NotationSet[],
): Record<string, NotationIndexEntry> {
  const classes = new Set<string>([...superClassMap.keys(), ...NOTATION_ROOTS]);
  for (const set of consultedSets) {
    for (const conceptIri of set.notations.keys()) classes.add(conceptIri);
  }
  const ordered = [...classes].sort(compareIris);

  const index = new Map<string, NotationIndexEntry>();
  for (const iri of ordered) {
    const entry = indexEntryFor(resolver.resolve(iri));
    if (entry) index.set(iri, entry);
  }
  for (const iri of ordered) {
    const entry = index.get(iri);
    if (!entry) continue;
    const predicate = objectValue(graph, iri, ARCH_UNQUALIFIED_FORM);
    if (!predicate || index.has(predicate)) continue;
    const inherited = closureOf(iri, superClassMap).some(
      (superClass) => objectValue(graph, superClass, ARCH_UNQUALIFIED_FORM) === predicate,
    );
    if (!inherited) index.set(predicate, entry);
  }
  return Object.fromEntries(index);
}

/** A resolved notation as index data, or `undefined` when nothing applies. */
function indexEntryFor(resolved: ResolvedNotation): NotationIndexEntry | undefined {
  if (resolved.source === 'default') return undefined;
  const style = styleWithResolvedIcon(resolved.notation);
  const relationshipStyle = resolved.notation?.relationshipStyle;
  return {
    source: resolved.source,
    ...(resolved.notationSetIri ? { notationSetIri: resolved.notationSetIri } : {}),
    ...(resolved.matchedClassIri ? { matchedClassIri: resolved.matchedClassIri } : {}),
    // The same derivation as a palette entry's `renderingMode`.
    ...(style ? { style, renderingMode: effectiveRenderingMode(style) } : {}),
    ...(relationshipStyle ? { relationshipStyle } : {}),
  };
}

/**
 * A descriptor's element style as renderers take it: the icon URL resolved to
 * the bundled copy when there is one. The published URI stays available on the
 * palette entry's `iconSymbol`.
 */
function styleWithResolvedIcon(notation: VisualNotation | undefined): VisualStyle | undefined {
  if (!notation?.style) return undefined;
  const iconSymbol = resolveUri(notation.style.iconSymbol);
  return { ...notation.style, iconSymbol: iconSymbol?.url ?? notation.style.iconSymbol };
}

/**
 * How a relationship type no notation describes is drawn (Req 2.25): it leads from its source to its target, so
 * with an open arrowhead at the target — the links of an extension that publishes no notation (a decision's, a
 * process's, an evaluation's) read by their direction. One whose direct predicate is symmetric
 * (`owl:SymmetricProperty`: core's Association) has no direction, and is a plain line.
 */
function unstyledRelationship(graph: Store, unqualifiedPredicateIri: string | undefined): RelationshipVisualStyle | undefined {
  const symmetric =
    unqualifiedPredicateIri !== undefined &&
    graph.getQuads(namedNode(unqualifiedPredicateIri), namedNode(RDF_TYPE), namedNode(OWL_SYMMETRIC_PROPERTY), null).length > 0;
  return symmetric ? undefined : { lineStyle: 'SolidLine', targetDecor: 'OpenArrowhead' };
}

/** True when the class carries `arch:isAbstractClass true`. */
function isAbstractClass(graph: Store, iri: string): boolean {
  return graph
    .getObjects(namedNode(iri), namedNode(ARCH_IS_ABSTRACT_CLASS), null)
    .some((term) => term.value === 'true');
}

/** First object value for subject + predicate, whatever the term type. */
function objectValue(graph: Store, subjectIri: string, predicate: string): string | undefined {
  for (const object of graph.getObjects(namedNode(subjectIri), namedNode(predicate), null)) {
    return object.value;
  }
  return undefined;
}

/** All named-node object values for subject + predicate. */
function objectValues(graph: Store, subjectIri: string, predicate: string): string[] {
  return graph
    .getObjects(namedNode(subjectIri), namedNode(predicate), null)
    .filter((term) => term.termType === 'NamedNode')
    .map((term) => term.value);
}

/** Preferred label: English `skos:prefLabel`, any `skos:prefLabel`, `rdfs:label`, else the IRI fragment. */
function labelFor(graph: Store, iri: string): string {
  for (const predicate of [SKOS_PREF_LABEL, RDFS_LABEL]) {
    const literals = graph
      .getObjects(namedNode(iri), namedNode(predicate), null)
      .filter((term) => term.termType === 'Literal');
    const english = literals.find((term) => 'language' in term && term.language === 'en');
    const chosen = english ?? literals[0];
    if (chosen) return chosen.value;
  }
  return fragmentToLabel(iriFragment(iri));
}

/** Definition: `skos:definition`, then `rdfs:comment`. */
function definitionFor(graph: Store, iri: string): string | undefined {
  return objectValue(graph, iri, SKOS_DEFINITION) ?? objectValue(graph, iri, RDFS_COMMENT);
}

/** Pair a published URI with its bundled path, when this bundle ships one. */
/** {@link buildDecorationSymbols}, each symbol resolved to its bundled copy where there is one. */
function resolvedDecorationSymbols(graph: Store): Partial<Record<Decoration, ResolvedUri>> {
  const resolved: Partial<Record<Decoration, ResolvedUri>> = {};
  for (const [decoration, uri] of Object.entries(buildDecorationSymbols(graph)) as Array<[Decoration, string]>) {
    const symbol = resolveUri(uri);
    if (symbol) resolved[decoration] = symbol;
  }
  return resolved;
}

function resolveUri(sourceUri: string | undefined): ResolvedUri | undefined {
  if (!sourceUri) return undefined;
  const bundledPath = resolveIconUri(sourceUri) ?? undefined;
  return { sourceUri, bundledPath, url: bundledPath ?? sourceUri };
}

/** Local name of an IRI: after the last `#`, or after the last `/`. */
function iriFragment(iri: string): string {
  return iri.includes('#') ? iri.slice(iri.lastIndexOf('#') + 1) : iri.slice(iri.lastIndexOf('/') + 1);
}

/** Humanises a local name: `BusinessActor` becomes `Business Actor`. */
function fragmentToLabel(fragment: string): string {
  return fragment
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function uniqueInOrder(items: string[]): string[] {
  return [...new Set(items)];
}

/**
 * Two stores read as one — what the palette's builders ask of a store
 * (`getQuads`, `getObjects`, `getSubjects`) — without copying either.
 */
function unionOf(a: Store, b: Store): Store {
  const distinct = <T extends { termType: string; value: string }>(terms: T[]): T[] => {
    const seen = new Set<string>();
    return terms.filter((t) => {
      const key = `${t.termType}:${t.value}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };
  type Args<K extends 'getQuads' | 'getObjects' | 'getSubjects'> = Parameters<Store[K]>;
  return {
    getQuads: (...args: Args<'getQuads'>) => [...a.getQuads(...args), ...b.getQuads(...args)],
    getObjects: (...args: Args<'getObjects'>) => distinct([...a.getObjects(...args), ...b.getObjects(...args)]),
    getSubjects: (...args: Args<'getSubjects'>) => distinct([...a.getSubjects(...args), ...b.getSubjects(...args)]),
  } as unknown as Store;
}

/**
 * Each relationship type's category: its group under a dimension that classifies relationship types — ArchiMate's
 * Relationship, its groups Structural, Dependency, Dynamic and Other; the decision extension's Relationship Kind —
 * or, for a kind of relationship the taxonomy does not list (ArchiMate 4.0's Read Access), its nearest superclass's.
 * A dimension lists a type by its class, or by a concept that stands for it (`rdfs:seeAlso`: LeanIX's, BPMN's).
 *
 * Several metamodels are loaded, each with its own: a type takes its category from the dimension that lists it —
 * of several, the one that lists the most relationship types: a dimension of element types may list one too (UML's
 * state machine diagram lists Transition), and is not their classification. A group under no dimension (LeanIX's
 * Relationship Type, BPMN's Connecting Objects) gives a category only beside a dimension that does: alone, the list
 * stays as it is.
 *
 * The types come dimension by dimension — the one that lists the most first — in the order of each one's groups
 * (its thesaurus array, ArchiMate's
 * `:RelationshipOrder`), then by name; a type of no category after them. Within a category, the order of the array
 * under it (ArchiMate's order of strength, weakest first), a kind just after the relationship it is a kind of, then
 * by name. With no dimension classifying a relationship type, the list is as it was.
 */
function categoriseRelationships(
  relationships: RelationshipTypeInfo[],
  axes: readonly TaxonomyAxis[],
  superClassMap: ReadonlyMap<string, readonly string[]>,
  graph: Store,
): RelationshipTypeInfo[] {
  const types = new Set(relationships.map((rel) => rel.iri));
  /** The relationship type a member of a dimension is, or stands for. */
  const typeOf = (member: string): string | undefined => {
    if (types.has(member)) return member;
    const linked = [
      ...graph.getObjects(namedNode(member), namedNode(RDFS_SEE_ALSO), null),
      ...graph.getSubjects(namedNode(RDFS_SEE_ALSO), namedNode(member), null),
    ];
    return linked.find((term) => types.has(term.value))?.value;
  };
  /** Per dimension that lists a relationship type: the member that lists each type. */
  const listing = axes
    .map((axis) => {
      const members = new Map<string, string>();
      for (const member of axis.groups.keys()) {
        const type = typeOf(member);
        if (type !== undefined && !members.has(type)) members.set(type, member);
      }
      return { axis, members };
    })
    .filter(({ members }) => members.size > 0)
    // The dimension that lists the most first: a metamodel's own relationship types before those of one it
    // imports (LeanIX's before the processes extension's).
    .sort((a, b) => b.members.size - a.members.size);
  const dimensions = listing.some(({ axis }) => !axis.standalone) ? listing : [];
  if (dimensions.length === 0) return relationships;

  const LAST = Number.MAX_SAFE_INTEGER;
  const placed = relationships.map((rel) => {
    const chain = [rel.iri, ...superClassesNearestFirst(rel.iri, superClassMap)];
    let best: { at: number; listed: string; member: string; size: number } | undefined;
    dimensions.forEach(({ members }, at) => {
      const listed = chain.find((iri) => members.has(iri));
      if (listed !== undefined && (!best || members.size > best.size)) {
        best = { at, listed, member: members.get(listed) as string, size: members.size };
      }
    });
    if (!best) return { rel, at: LAST, rank: LAST, memberRank: LAST, isKind: 0 };
    const { axis } = dimensions[best.at]!;
    const category = axis.groups.get(best.member);
    return {
      rel: category ? { ...rel, category } : rel,
      at: best.at,
      rank: axis.ranks.get(best.member) ?? LAST - 1,
      // Within its category: the category's own array (ArchiMate's order of strength), a kind just after the
      // relationship it is a kind of, then by name.
      memberRank: axis.memberRanks?.get(best.member) ?? LAST,
      isKind: best.listed !== rel.iri ? 1 : 0,
    };
  });
  return placed
    .sort(
      (a, b) =>
        a.at - b.at ||
        a.rank - b.rank ||
        (a.rel.category ?? '').localeCompare(b.rel.category ?? '') ||
        a.memberRank - b.memberRank ||
        a.isKind - b.isKind ||
        a.rel.label.localeCompare(b.rel.label),
    )
    .map(({ rel }) => rel);
}

/**
 * A class's palette section under the grouping axes, the active one first: its group under the first of them
 * that classifies it, which axis that is (its index) and its rank there; none when none does.
 */
function sectionOf(
  cls: SemanticClass,
  groupingAxes: readonly string[],
): { group: string; axis: number; rank?: number } | undefined {
  for (let axis = 0; axis < groupingAxes.length; axis++) {
    const iri = groupingAxes[axis]!;
    const group = cls.groupsByAxis[iri];
    if (group) return { group, axis, ...(cls.ranksByAxis[iri] !== undefined ? { rank: cls.ranksByAxis[iri] } : {}) };
  }
  return undefined;
}

/** An axis's group labels: in the axis's order where it has one (by the lowest rank of their members), then by label. */
function groupsInOrder(axis: TaxonomyAxis): string[] {
  const rank = new Map<string, number>();
  for (const [member, label] of axis.groups) {
    const r = axis.ranks.get(member);
    if (r !== undefined) rank.set(label, Math.min(rank.get(label) ?? r, r));
  }
  const LAST = Number.MAX_SAFE_INTEGER;
  return uniqueInOrder([...axis.groups.values()]).sort(
    (a, b) => (rank.get(a) ?? LAST) - (rank.get(b) ?? LAST) || a.localeCompare(b),
  );
}
