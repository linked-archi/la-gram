/**
 * SHACL Validator implementation using rdf-validate-shacl.
 *
 * Validates RDF data graphs against SHACL shapes graphs,
 * supporting both full validation and incremental (single-resource) validation.
 */

import SHACLValidator from 'rdf-validate-shacl';
import { isInstanceOf } from 'rdf-validate-shacl/src/dataset-utils.js';
import { Store as N3Store, DataFactory } from 'n3';
import type { Quad, NamedNode, Term } from '@rdfjs/types';
import type {
  ShaclValidator,
  ValidationReport,
  ValidationResult,
  ValidationSeverity,
} from './interfaces.js';

const { namedNode } = DataFactory;

const SH = 'http://www.w3.org/ns/shacl#';
const SKOS_PREF_LABEL = 'http://www.w3.org/2004/02/skos/core#prefLabel';
const RDFS_LABEL = 'http://www.w3.org/2000/01/rdf-schema#label';

/** sh:sparql — SPARQL-based constraints, unsupported by rdf-validate-shacl. */
const SH_SPARQL = `${SH}sparql`;
/** sh:SPARQLConstraintComponent — the component rdf-validate-shacl cannot resolve. */
const SH_SPARQL_CONSTRAINT_COMPONENT = `${SH}SPARQLConstraintComponent`;
/** sh:message — used to tell an authored message from a library default. */
const SH_MESSAGE = `${SH}message`;

/** How deep to walk sh:detail sub-results looking for a usable message. */
const MAX_DETAIL_DEPTH = 5;

/** SHACL severity IRIs mapped to our union type. */
const SEVERITY_MAP: Record<string, ValidationSeverity> = {
  [`${SH}Violation`]: 'Violation',
  [`${SH}Warning`]: 'Warning',
  [`${SH}Info`]: 'Info',
};

/**
 * Options accepted by rdf-validate-shacl.
 *
 * The bundled type declarations for 0.5.x do not include `importGraph`, but
 * newer releases resolve `owl:imports` in the shapes graph over the network
 * when it is absent. la-gram loads every import into the store up front and
 * must never fetch (it would fail in Electron over `file://`), so we always
 * pass a no-op resolver. Widening the type here keeps that forward-compatible
 * without an `any` cast at the call site.
 */
type ValidatorOptions = ConstructorParameters<typeof SHACLValidator>[1] & {
  importGraph?: () => Promise<N3Store>;
};

/** Minimal structural view of a rdf-validate-shacl result, incl. nested details. */
interface ResultLike {
  message?: readonly { value: string }[];
  detail?: readonly ResultLike[];
}

/**
 * Concrete implementation of ShaclValidator backed by rdf-validate-shacl.
 */
export class RdfShaclValidator implements ShaclValidator {
  /**
   * The compiled validator for the last shapes graph, keyed by the array's
   * identity. Compiling is the expensive part — the ArchiMate relationship
   * shapes alone are 70 000 quads — and the shapes only change when a
   * metamodel is loaded or dropped, so callers that pass the same array get the
   * same engine back.
   */
  private cache: { shapes: Quad[]; engine: CompiledShapes } | null = null;

  validate(dataGraph: Quad[], shapesGraph: Quad[]): ValidationReport {
    return runCompiledOn(this.compiled(shapesGraph), quadsToStore(dataGraph));
  }

  /**
   * Validate the data graph a store holds — every graph in it — as it is: no
   * copy made. For a caller that keeps its data graph in a store of its own
   * (the validation engine, Task 22).
   */
  validateStore(data: N3Store, shapesGraph: Quad[], options: RunOptions = {}): ValidationReport {
    const engine = this.compiled(shapesGraph);
    guard(engine, options);
    return runCompiledOn(engine, data);
  }

  /**
   * Validate only these focus nodes of the data graph a store holds: each
   * against the shapes that target it — chosen as a whole validation chooses
   * them (a class target with the data's subclasses, `sh:targetNode`,
   * `sh:targetSubjectsOf`, `sh:targetObjectsOf`) — so that its findings are
   * the whole validation's findings for those nodes (Task 22).
   */
  validateNodes(data: N3Store, shapesGraph: Quad[], focus: readonly Term[], options: RunOptions = {}): ValidationReport {
    const engine = this.compiled(shapesGraph);
    guard(engine, options);
    const lib = engine.validator as unknown as LibraryInternals;
    engine.targets ??= targetsOf(lib);
    lib.setDataGraph(data);
    const run = lib.validationEngine;
    run.initReport();
    const classesOf = classMembership(data);
    const nodes = focus.filter((n) => n.termType === 'NamedNode' || n.termType === 'BlankNode');
    for (const target of engine.targets) {
      for (const node of nodes) {
        if (isTarget(target, node, data, classesOf)) run.validateNodeAgainstShape(node, target.shape, lib.$data);
      }
    }
    try {
      return toValidationReport(run.getReport(), engine.shapesStore, data);
    } finally {
      release(engine.validator);
    }
  }

  private compiled(shapesGraph: Quad[]): CompiledShapes {
    if (this.cache?.shapes !== shapesGraph) {
      this.cache = { shapes: shapesGraph, engine: compileShapes(shapesGraph) };
    }
    return this.cache.engine;
  }

  validateIncremental(
    changedResource: NamedNode,
    dataGraph: Quad[],
    shapesGraph: Quad[],
  ): ValidationReport {
    // Filter data graph to only triples where the changed resource is the subject
    const filteredQuads = dataGraph.filter(
      (q) => q.subject.value === changedResource.value,
    );

    return runValidation(filteredQuads, shapesGraph);
  }
}

/** Build the validator, run it, and map the report. Shared by both entry points. */
/** A shapes graph compiled into a reusable engine. */
interface CompiledShapes {
  validator: SHACLValidator;
  shapesStore: N3Store;
  /** The library's own limit of checks of a node against a shape in a run. */
  nodeChecks: number;
  /** What each shape with a target targets, read when nodes are first validated alone. */
  targets?: ShapeTargets[];
}

/** How to run a validation. */
export interface RunOptions {
  /**
   * Whether to stop checking a node against a shape after 50 checks in one
   * run — rdf-validate-shacl's guard against a shape nested in itself. When no
   * shape is (`shapesReach`), it only makes a node referred to from many
   * places pass unchecked after the 50th, and differently when nodes are
   * validated alone; and keying its counter costs a JSON string per check.
   * Default: on.
   */
  recursionGuard?: boolean;
}

/** What of rdf-validate-shacl's internals validating chosen nodes uses (0.5). */
interface LibraryInternals {
  $shapes: { node(term: Term): unknown; dataset: { match(s: Term | null, p: Term | null, o: Term | null): Iterable<Quad> } };
  $data: unknown;
  ns: { rdfs: { Class: Term } };
  shapesGraph: { shapesWithTarget: LibraryShape[] };
  setDataGraph(data: unknown): void;
  validationEngine: {
    maxNodeChecks: number;
    initReport(): void;
    validateNodeAgainstShape(node: Term, shape: LibraryShape, data: unknown): boolean;
    getReport(): ReturnType<SHACLValidator['validate']>;
  };
}

interface LibraryShape {
  shapeNode: Term;
  shapeNodePointer: { out(predicate: Term): { terms: Term[] } };
}

/** What a shape targets. */
interface ShapeTargets {
  shape: LibraryShape;
  /** Classes whose instances it targets — itself, when it is a class (an implicit target). */
  classes: string[];
  nodes: Set<string>;
  subjectsOf: Term[];
  objectsOf: Term[];
}

const RDF_TYPE = namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type');
const RDFS_SUBCLASS_OF = namedNode('http://www.w3.org/2000/01/rdf-schema#subClassOf');

function targetsOf(lib: LibraryInternals): ShapeTargets[] {
  const out = (shape: LibraryShape, predicate: string) => shape.shapeNodePointer.out(namedNode(SH + predicate) as unknown as Term).terms;
  return lib.shapesGraph.shapesWithTarget.map((shape) => {
    const classes = [...lib.$shapes.dataset.match(shape.shapeNode, namedNode(SH + 'targetClass') as unknown as Term, null)].map((q) => q.object.value);
    if (isInstanceOf(lib.$shapes.node(shape.shapeNode) as never, lib.$shapes.node(lib.ns.rdfs.Class) as never, lib.ns as never)) {
      classes.push(shape.shapeNode.value);
    }
    return {
      shape,
      classes,
      nodes: new Set(out(shape, 'targetNode').map((t) => t.value)),
      subjectsOf: out(shape, 'targetSubjectsOf'),
      objectsOf: out(shape, 'targetObjectsOf'),
    };
  });
}

/** A node's classes in the data: its types and their superclasses there. */
function classMembership(data: N3Store): (node: Term) => Set<string> {
  const supers = new Map<string, string[]>();
  const superclasses = (cls: Term): string[] => {
    const known = supers.get(cls.value);
    if (known) return known;
    const seen = new Map<string, Term>([[cls.value, cls]]);
    const stack = [cls];
    while (stack.length > 0) {
      const current = stack.pop() as Term;
      for (const parent of data.getObjects(current as never, RDFS_SUBCLASS_OF, null)) {
        if (!seen.has(parent.value)) {
          seen.set(parent.value, parent as unknown as Term);
          stack.push(parent as unknown as Term);
        }
      }
    }
    const all = [...seen.keys()];
    supers.set(cls.value, all);
    return all;
  };
  return (node) => {
    const classes = new Set<string>();
    for (const type of data.getObjects(node as never, RDF_TYPE, null)) for (const c of superclasses(type as unknown as Term)) classes.add(c);
    return classes;
  };
}

/** Whether a shape targets the node — as `Shape.getTargetNodes` decides it. */
function isTarget(target: ShapeTargets, node: Term, data: N3Store, classesOf: (node: Term) => Set<string>): boolean {
  if (target.classes.length > 0) {
    const classes = classesOf(node);
    if (target.classes.some((c) => classes.has(c))) return true;
  }
  if (target.nodes.has(node.value)) {
    const n = node as never;
    if (data.countQuads(n, null, null, null) + data.countQuads(null, n, null, null) + data.countQuads(null, null, n, null) > 0) return true;
  }
  if (target.subjectsOf.some((p) => data.countQuads(node as never, p as never, null, null) > 0)) return true;
  return target.objectsOf.some((p) => data.countQuads(null, p as never, node as never, null) > 0);
}

/** Set the library's per-run limit of checks of a node against a shape. */
function guard(engine: CompiledShapes, options: RunOptions): void {
  const lib = engine.validator as unknown as LibraryInternals;
  lib.validationEngine.maxNodeChecks = options.recursionGuard === false ? 0 : engine.nodeChecks;
}

function compileShapes(shapesGraph: Quad[]): CompiledShapes {
  const usableShapes = stripSparqlConstraints(shapesGraph);
  const shapesStore = quadsToStore(usableShapes);
  const options: ValidatorOptions = {
    importGraph: () => Promise.resolve(new N3Store()),
  };
  const validator = new SHACLValidator(shapesStore, options);
  const nodeChecks = (validator as unknown as LibraryInternals).validationEngine.maxNodeChecks;
  return { validator, shapesStore, nodeChecks };
}

function runCompiledOn(engine: CompiledShapes, dataStore: N3Store): ValidationReport {
  const report = engine.validator.validate(dataStore);
  try {
    return toValidationReport(report, engine.shapesStore, dataStore);
  } finally {
    release(engine.validator);
  }
}

/**
 * Drop what a run kept for itself once its report is read: rdf-validate-shacl
 * holds, until the next run, a counter per node and shape it checked (keyed by
 * both, as JSON), the report's own graph, and the data graph — 250 MB after a
 * run on a 350 000-triple model (Task 22). A compiled validator is kept between
 * runs, so they were kept too.
 */
function release(validator: SHACLValidator): void {
  const internal = validator as unknown as { $data?: unknown; validationEngine?: { initReport?(): void } };
  internal.validationEngine?.initReport?.();
  internal.$data = undefined;
}

function runValidation(dataGraph: Quad[], shapesGraph: Quad[]): ValidationReport {
  return runCompiledOn(compileShapes(shapesGraph), quadsToStore(dataGraph));
}

/**
 * Remove SPARQL-based SHACL constraints from a shapes graph.
 *
 * rdf-validate-shacl has no validator for `sh:SPARQLConstraintComponent` and
 * throws "Cannot find validator for constraint component ..." the moment a
 * shape carrying one is evaluated. Published Linked.Archi shape files use
 * `sh:sparql` heavily (self-loop and cycle detection, for instance), so we
 * drop those constraints rather than fail the whole validation run.
 *
 * Dropping the two quad patterns is sufficient. The blank nodes that held the
 * `sh:select` / `sh:prefixes` / `sh:message` bodies stay in the graph, but once
 * the `sh:sparql` link is gone nothing reaches them: they are not typed as
 * `sh:NodeShape` or `sh:PropertyShape`, so they are not implicit class targets,
 * and no shape references them. Verified against the real ArchiMate 4.0
 * element shapes, which contain 20 such quads.
 *
 * The tradeoff is real: shapes whose *only* constraint is `sh:sparql` become
 * inert, so their rule is silently not enforced.
 */
function stripSparqlConstraints(quads: Quad[]): Quad[] {
  return quads.filter(
    (q) =>
      q.predicate.value !== SH_SPARQL &&
      q.object.value !== SH_SPARQL_CONSTRAINT_COMPONENT,
  );
}

/** Convert an array of quads into an N3.js Store (RDF/JS DatasetCore). */
function quadsToStore(quads: Quad[]): N3Store {
  const store = new N3Store();
  store.addQuads(quads as Parameters<typeof store.addQuads>[0]);
  return store;
}

/** Map the library's ValidationReport to our interface. */
function toValidationReport(
  report: ReturnType<SHACLValidator['validate']>,
  shapesStore: N3Store,
  dataStore: N3Store,
): ValidationReport {
  const results: ValidationResult[] = report.results.map((r) => {
    const severityIri = r.severity?.value ?? `${SH}Violation`;
    const severity: ValidationSeverity = SEVERITY_MAP[severityIri] ?? 'Violation';

    const focusNode = r.focusNode?.value ?? '';
    const path = r.path?.value ?? '';
    const sourceShape = r.sourceShape?.value ?? '';
    const sourceComponent = r.sourceConstraintComponent?.value ?? '';
    const value = r.value?.value ?? '';

    const message = resolveMessage({
      result: r,
      shapesStore,
      dataStore,
      shapeTerm: r.sourceShape ?? null,
      focusNode,
      sourceShape,
      sourceComponent,
      path,
      value,
    });

    const mapped: ValidationResult = {
      focusNode: namedNode(focusNode),
      resultPath: namedNode(path),
      sourceShape: namedNode(sourceShape),
      message,
      severity,
    };
    if (sourceComponent) {
      mapped.sourceConstraintComponent = namedNode(sourceComponent);
    }
    const within = r.sourceShape?.termType === 'BlankNode' ? enclosingShape(shapesStore, r.sourceShape) : undefined;
    if (within) mapped.withinShape = namedNode(within);
    return mapped;
  });

  return {
    conforms: report.conforms,
    results,
  };
}

/** What writes a shape inside another: a property, a nested shape, a list of shapes. */
const ENCLOSING = new Set(
  ['property', 'node', 'not', 'qualifiedValueShape', 'or', 'and', 'xone'].map((p) => SH + p).concat(
    ['first', 'rest'].map((p) => 'http://www.w3.org/1999/02/22-rdf-syntax-ns#' + p),
  ),
);

/** Per shapes graph, the named shape each inline shape is written in. */
const enclosingCache = new WeakMap<N3Store, Map<string, string | undefined>>();

/**
 * The named shape an inline shape (a blank node) is written in: up through
 * `sh:property`, `sh:node`, `sh:not`, `sh:qualifiedValueShape` and the lists of
 * `sh:or`, `sh:and`, `sh:xone`, to the first named node. None when it is
 * written in nothing named.
 *
 * Exported for direct testing.
 */
export function enclosingShape(shapesStore: N3Store, shape: Term): string | undefined {
  let cache = enclosingCache.get(shapesStore);
  if (!cache) enclosingCache.set(shapesStore, (cache = new Map()));
  if (cache.has(shape.value)) return cache.get(shape.value);
  const seen = new Set<string>([shape.value]);
  let level: Term[] = [shape];
  let found: string | undefined;
  while (level.length > 0 && !found) {
    const next: Term[] = [];
    for (const term of level) {
      for (const q of shapesStore.getQuads(null, null, term as never, null)) {
        if (!ENCLOSING.has(q.predicate.value)) continue;
        if (q.subject.termType === 'NamedNode') {
          found = q.subject.value;
          break;
        }
        if (!seen.has(q.subject.value)) {
          seen.add(q.subject.value);
          next.push(q.subject as Term);
        }
      }
      if (found) break;
    }
    level = next;
  }
  cache.set(shape.value, found);
  return found;
}

/**
 * Pick the most useful message available for a result.
 *
 * Precedence:
 *  1. A message the shape author declared with `sh:message`. Checked against
 *     the shapes graph rather than by string-matching, because
 *     rdf-validate-shacl also emits terse built-in messages ("Less than 1
 *     values") that are indistinguishable from authored ones on the result.
 *  2. The deepest message found in nested `sh:detail` sub-results. `sh:node`
 *     violations report only "Value does not have shape <X>" at the top level
 *     and bury the actionable message one or more levels down.
 *  3. A synthesised message built from the constraint component.
 */
function resolveMessage(ctx: {
  result: ResultLike;
  shapesStore: N3Store;
  dataStore: N3Store;
  shapeTerm: Term | null;
  focusNode: string;
  sourceShape: string;
  sourceComponent: string;
  path: string;
  value: string;
}): string {
  if (hasAuthoredMessage(ctx.shapesStore, ctx.shapeTerm)) {
    const authored = firstMessage(ctx.result);
    if (authored) return authored;
  }

  const nested = deepestDetailMessage(ctx.result);
  if (nested) return nested;

  return buildReadableMessage(
    ctx.focusNode,
    ctx.sourceShape,
    ctx.sourceComponent,
    ctx.path,
    ctx.value,
    ctx.dataStore,
  );
}

/** True when the shape node carries an explicit `sh:message` in the shapes graph. */
function hasAuthoredMessage(shapesStore: N3Store, shapeTerm: Term | null): boolean {
  if (!shapeTerm) return false;
  if (shapeTerm.termType !== 'NamedNode' && shapeTerm.termType !== 'BlankNode') {
    return false;
  }
  return (
    shapesStore.countQuads(
      shapeTerm as Parameters<N3Store['countQuads']>[0],
      namedNode(SH_MESSAGE),
      null,
      null,
    ) > 0
  );
}

/** Join the messages on a single result into one string, or '' when there are none. */
function firstMessage(result: ResultLike): string {
  const messages = result.message ?? [];
  return messages
    .map((m) => m.value)
    .filter((v) => v.length > 0)
    .join('; ');
}

/**
 * Walk `sh:detail` sub-results depth-first and return the innermost message.
 *
 * Nesting is produced by `sh:node` constraints, where every level above the
 * leaf says only "Value does not have shape <X>". Preferring the deepest
 * message surfaces the leaf constraint that actually failed.
 *
 * Exported for direct testing.
 */
export function deepestDetailMessage(result: ResultLike, depth = 0): string {
  if (depth >= MAX_DETAIL_DEPTH) return '';

  const details = result.detail ?? [];
  for (const detail of details) {
    const deeper = deepestDetailMessage(detail, depth + 1);
    if (deeper) return deeper;
    const own = firstMessage(detail);
    if (own) return own;
  }
  return '';
}

/** Shorten an IRI to its local name for display. */
function shortenIri(iri: string): string {
  if (!iri) return '';
  const hash = iri.lastIndexOf('#');
  if (hash >= 0) return iri.slice(hash + 1);
  const slash = iri.lastIndexOf('/');
  if (slash >= 0) return iri.slice(slash + 1);
  return iri;
}

/**
 * Look up a display label for a node in the data graph.
 * Prefers skos:prefLabel, then rdfs:label, then the IRI local name.
 */
function labelFor(dataStore: N3Store, iri: string): string {
  if (!iri) return 'node';
  for (const predicate of [SKOS_PREF_LABEL, RDFS_LABEL]) {
    const quads = dataStore.getQuads(namedNode(iri), namedNode(predicate), null, null);
    if (quads.length > 0 && quads[0].object.value) return quads[0].object.value;
  }
  return shortenIri(iri);
}

/**
 * Synthesise a human-readable message for a violation whose shape declares no
 * `sh:message`. Ported from the la-modeller-excalidraw validator, with scene
 * lookups replaced by data-graph label lookups.
 *
 * Exported for direct testing.
 */
export function buildReadableMessage(
  focusNode: string,
  sourceShape: string,
  sourceComponent: string,
  path: string,
  value: string,
  dataStore: N3Store,
): string {
  const elementLabel = labelFor(dataStore, focusNode);
  const component = shortenIri(sourceComponent);
  const shapeName = shortenIri(sourceShape);
  const pathName = shortenIri(path);

  if (component === 'OrConstraintComponent') {
    return `"${elementLabel}" violates ${shapeName} — none of the allowed source/target combinations match.`;
  }
  if (component === 'ClassConstraintComponent') {
    return `"${elementLabel}" has invalid ${pathName || 'value'}: ${shortenIri(value)} is not an allowed class for ${shapeName}.`;
  }
  if (component === 'MinCountConstraintComponent') {
    return `"${elementLabel}" is missing required property "${pathName}" (required by ${shapeName}).`;
  }
  if (component === 'MaxCountConstraintComponent') {
    return `"${elementLabel}" has too many values for "${pathName}" (constrained by ${shapeName}).`;
  }
  if (component === 'DatatypeConstraintComponent') {
    return `"${elementLabel}" has wrong datatype for "${pathName}" (expected by ${shapeName}).`;
  }
  if (component === 'NodeKindConstraintComponent') {
    return `"${elementLabel}" has a value of the wrong node kind for "${pathName}" (expected by ${shapeName}).`;
  }
  if (component === 'NodeConstraintComponent' || component === 'AndConstraintComponent') {
    return `"${elementLabel}" does not satisfy all constraints in ${shapeName}.`;
  }

  return `"${elementLabel}" violates ${shapeName || 'a SHACL constraint'}${pathName ? ` on property "${pathName}"` : ''} (${component || 'unknown component'}).`;
}
